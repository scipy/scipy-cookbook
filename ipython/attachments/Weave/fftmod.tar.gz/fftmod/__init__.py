"""
This module provides 1/2-D FFTs for functions taken on the interval
n = [-N/2, ..., N/2-1] in all transformed directions. This is accomplished
quickly by making a change of variables in the DFT expression, leading to
multiplication of exp(+/-jPIk) * DFT{exp(+/-jPIn) * [n]}. Take notice that
BOTH your input and output arrays will be arranged on the negative-to-positive
interval. To take regular FFTs, shifting can be turned off.
"""
import numpy as N
from scipy.weave import inline
from os.path import join, split
from numpy.distutils.system_info import get_info        

fft1_code = \
"""
char *i, *o;
i = (char *) a;
o = inplace ? i : (char *) b;
if(isfloat) {
  cfft1d(reinterpret_cast<fftwf_complex*>(i),
         reinterpret_cast<fftwf_complex*>(o),
         xdim, len_array, direction, shift);
} else {
  zfft1d(reinterpret_cast<fftw_complex*>(i),
         reinterpret_cast<fftw_complex*>(o),
         xdim, len_array, direction, shift);
}
"""
fft2_code = \
"""
char *i, *o;
i = (char *) a;
o = inplace ? i : (char *) b;
if(isfloat) {
  cfft2d(reinterpret_cast<fftwf_complex*>(i),
         reinterpret_cast<fftwf_complex*>(o),
         xdim, ydim, len_array, direction, shift);
} else {
  zfft2d(reinterpret_cast<fftw_complex*>(i),
         reinterpret_cast<fftw_complex*>(o),
         xdim, ydim, len_array, direction, shift);
}
"""
extra_code = open(join(split(__file__)[0],'src/cmplx_fft.c')).read()
fftw_info = get_info('fftw3')

def fft1(a, shift=True, inplace=False):
    if inplace:
        _fft1_work(a, -1, shift, inplace)
    else:
        return _fft1_work(a, -1, shift, inplace)

def ifft1(a, shift=True, inplace=False):
    if inplace:
        _fft1_work(a, +1, shift, inplace)
    else:
        return _fft1_work(a, +1, shift, inplace)

def fft2(a, shift=True, inplace=False):
    if inplace:
        _fft2_work(a, -1, shift, inplace)
    else:
        return _fft2_work(a, -1, shift, inplace)

def ifft2(a, shift=True, inplace=False):
    if inplace:
        _fft2_work(a, +1, shift, inplace)
    else:
        return _fft2_work(a, +1, shift, inplace)

def _fft1_work(a, direction, shift, inplace):
    # to get correct C-code, b always must be an array (but if it's
    # not being used, it can be trivially small)
    b = N.empty_like(a) if not inplace else N.array([1j], a.dtype)
    inplace = 1 if inplace else 0
    shift = 1 if shift else 0    
    isfloat = 1 if a.dtype.itemsize==8 else 0
    len_array = N.product(a.shape)
    xdim = a.shape[-1]
    inline(fft1_code, ['a', 'b', 'isfloat', 'inplace',
                       'len_array', 'xdim', 'direction', 'shift'],
           support_code=extra_code,
           headers=['<fftw3.h>'],
           libraries=['fftw3', 'fftw3f'],
           include_dirs=fftw_info['include_dirs'],
           library_dirs=fftw_info['library_dirs'],
           compiler='gcc')
    if not inplace:
        return b

def _fft2_work(a, direction, shift, inplace):
    # to get correct C-code, b always must be an array (but if it's
    # not being used, it can be trivially small)
    b = N.empty_like(a) if not inplace else N.array([1j], a.dtype)
    inplace = 1 if inplace else 0
    shift = 1 if shift else 0
    isfloat = 1 if a.dtype.itemsize==8 else 0
    len_array = N.product(a.shape)
    ydim, xdim = a.shape[-2:]
    inline(fft2_code, ['a', 'b', 'isfloat', 'inplace',
                       'len_array', 'xdim', 'ydim', 'direction', 'shift'],
           support_code=extra_code,
           headers=['<fftw3.h>'],
           libraries=['fftw3', 'fftw3f'],
           include_dirs=fftw_info['include_dirs'],
           library_dirs=fftw_info['library_dirs'],
           compiler='gcc')
    if not inplace:
        return b
    
